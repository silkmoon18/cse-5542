Control:
    a, d, s, w: ambient only, diffuse only, specular only and combined.
    t, f, g, h, r, y: move the object up, left, down, right, forward and backward.
    q, e: rotate the object .
    p, P: scale the object.
    z, x, c, v: rotate the arms and legs.
    i, j, k, l, u, o: move camera up, left, down, right, forward and backward.
    1, 2, 3, 4, 5, 6: move light left, right, up, down, forward and backward.
    Other controls can be done through the buttons. 