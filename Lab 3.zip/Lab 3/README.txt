Control:
    w, a, s, d: move up, left, down and right
    r, t, y: rotate left arm, forearm and hand counterclockwise
    R, T, Y: rotate right arm, forearm and hand counterclockwise
    u: rotate head counterclockwise
    f, g, h: rotate left thigh, leg and feet counterclockwise
    F, G, H: rotate right thigh, leg and feet counterclockwise